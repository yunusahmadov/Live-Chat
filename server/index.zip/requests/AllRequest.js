module.exports = {
    users: [
        "name",
        "email",
        "password",
    ],
    messages: [
        "from_id",
        "to_id",
        "message"
    ]
}